package com.example.Uservice.Uservice.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.logging.log4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.Uservice.Uservice.Exception.ResourceNotFoundException;
import com.example.Uservice.Uservice.entity.Hotel;
import com.example.Uservice.Uservice.entity.Rating;
import com.example.Uservice.Uservice.entity.User;
import com.example.Uservice.Uservice.repository.UserRepository;





@Service
public class UserServiceImpl {

	@Autowired
	private UserRepository userRepository;
	
	
	
	//for fetch rating here from rating service
	//we need to use Rest Template
	
	
	@Autowired
    private RestTemplate restTemplate;  
	public User saveuser(User user) {
		// TODO Auto-generated method stub

		String randomUserId =UUID.randomUUID().toString();
		user.setUserId(randomUserId);
		return userRepository.save(user);
		
	}

	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		
	List<User> user=	userRepository.findAll();
		return user;
	}

	public User getuser(String userId) {
		// TODO Auto-generated method stub
		
		User user= userRepository.findById(userId).orElseThrow(
				() -> new ResourceNotFoundException("User with given id is not found on server :!!" + userId));
         
		//fetch rating here from rating service
	Rating[] ratingofuser=restTemplate.getForObject("http://RATING/ratings/users/"+ userId, Rating[].class);
		
	List<Rating>ratings=Arrays.stream(ratingofuser).toList();
	
	List<Rating>ratingList=   ratings.stream().map(rating ->{
		ResponseEntity<Hotel> forEntity=restTemplate.getForEntity("http://HOTEL-SERVICE/hotels/6549ab63-6599-4fd0-a020-e71aa3ca0b14", Hotel.class);
		Hotel hotel=forEntity.getBody();
		rating.setHotel(hotel);
		//+rating.getHotelId()
		return rating;
		
	}).collect(Collectors.toList());
		user.setRating(ratingList);
		return user;
	}

	
	
	
	
	
	
}
