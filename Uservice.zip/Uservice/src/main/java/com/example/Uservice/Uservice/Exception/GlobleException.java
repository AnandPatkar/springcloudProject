package com.example.Uservice.Uservice.Exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.Uservice.Uservice.payload.ApiResponse;




@RestControllerAdvice
public class GlobleException {
	
	
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ApiResponse> handlerResourceNotFondException(ResourceNotFoundException ex){
		String Message=ex.getMessage();
		ApiResponse response=new ApiResponse(Message,true,HttpStatus.NOT_FOUND);
	
	return new ResponseEntity<ApiResponse>(response,HttpStatus.NOT_FOUND);
	}
	
	

	
}
