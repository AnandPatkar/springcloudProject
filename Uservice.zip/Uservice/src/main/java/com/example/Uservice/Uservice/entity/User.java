package com.example.Uservice.Uservice.entity;





import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.beans.factory.annotation.Autowired;



@Entity
@Table(name= "micro_users")
public class User {
	
	
	
	@Id
	@Column(name = "Id")
	private String userId;
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAbout() {
		return about;
	}
	public void setAbout(String about) {
		this.about = about;
	}
	@Column(name = "Name",length = 20)
	private String name;
	@Column(name = "Email")
	private String email;
	@Column(name = "About")
	private String about ;
	@Transient
	private List<Rating> rating;
	/*@Autowired
	@Transient
	private List<Rating> rating=new ArrayList<>();
	*/
	public List<Rating> getRating() {
		return rating;
	}
	public void setRating(List<Rating> rating) {
		this.rating = rating;
	}
	
	
	
	

}
