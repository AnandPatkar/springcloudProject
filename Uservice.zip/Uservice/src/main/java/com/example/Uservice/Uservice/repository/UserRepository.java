package com.example.Uservice.Uservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Uservice.Uservice.entity.User;



public interface UserRepository extends JpaRepository<User,String> {

}
