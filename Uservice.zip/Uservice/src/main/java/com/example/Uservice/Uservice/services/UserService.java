package com.example.Uservice.Uservice.services;

import java.util.List;

import com.example.Uservice.Uservice.entity.User;



public interface UserService {

	
	//create
	User saveuser(User user);
	
	//get all users
	List<User> getAllUser();
	
	//get single user by userid
	
	User getuser(String userId);
	
	
	
	
	
}
