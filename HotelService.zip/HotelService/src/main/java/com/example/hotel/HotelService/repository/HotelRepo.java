package com.example.hotel.HotelService.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.hotel.HotelService.entity.Hotel;

public interface HotelRepo extends JpaRepository <Hotel, String>{

	
}
