package com.example.hotel.HotelService.services;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hotel.HotelService.Exception.ResourceNotFoundException;
import com.example.hotel.HotelService.entity.Hotel;
import com.example.hotel.HotelService.repository.HotelRepo;


@Service
public class HotelServiceImpl implements HotelService {

	
	
	
	@Autowired
	private HotelRepo hotelrepo;
	
	@Override
	public Hotel create(Hotel hotel) {
		// TODO Auto-generated method stub
		String randomUserId =UUID.randomUUID().toString();
		hotel.setId(randomUserId);
		return hotelrepo.save(hotel);
	}

	@Override
	public List<Hotel> getAll() {
		// TODO Auto-generated method stub
		return hotelrepo.findAll();
	}

	
	@Override
	public Hotel get(String id) {
		// TODO Auto-generated method stub
		return hotelrepo.findById(id).orElseThrow(
				() -> new ResourceNotFoundException("Hotel with given id is not found on server :!!"));
	}

	
}
