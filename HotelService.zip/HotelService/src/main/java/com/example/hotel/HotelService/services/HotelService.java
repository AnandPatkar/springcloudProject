package com.example.hotel.HotelService.services;

import java.util.List;

import com.example.hotel.HotelService.entity.Hotel;

public interface HotelService {

	
	//create or save
	
	Hotel create(Hotel hotel);
	
	//getall
	
	List<Hotel> getAll();
	
	//get single
	
	Hotel get(String id);
	
	
}
