package com.example.rating.RatingService.services;

import java.util.List;

import com.example.rating.RatingService.entity.Rating;

public interface RatingService {

	//create
	
	Rating create(Rating rating);
	
	//get all rating
	
	List<Rating> getRatings();
	
	//get all by UserId
	
	
	List<Rating> getRatingsByUserID(String userId);
	
	
	//get all by hotel
	
	List<Rating> getRatingsByHotelId(String hotelId);
	
	
}
