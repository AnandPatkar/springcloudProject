package com.example.rating.RatingService.services;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.rating.RatingService.entity.Rating;
import com.example.rating.RatingService.repository.RatingRepo;

@Service
public class RatingServiceImpl implements RatingService {

	
	@Autowired
	private RatingRepo ratingRepo;
	
	
	
	@Override
	public Rating create(Rating rating) {
		// TODO Auto-generated method stub
		String randomUserId =UUID.randomUUID().toString();
		rating.setRatingId(randomUserId);
		
		return ratingRepo.save(rating);
	}

	
	@Override
	public List<Rating> getRatings() {
		// TODO Auto-generated method stub
		return ratingRepo.findAll();
	}
	

	@Override
	public List<Rating> getRatingsByUserID(String userId) {
		// TODO Auto-generated method stub
		return ratingRepo.findByUserId(userId);
	}

	@Override
	public List<Rating> getRatingsByHotelId(String hotelId) {
		// TODO Auto-generated method stub
		return ratingRepo.findByHotelId(hotelId);
	}

}


